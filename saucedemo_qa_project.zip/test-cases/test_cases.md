# Test Cases

- TC-001: Login with valid credentials
- TC-002: Login with invalid credentials
- TC-003: Add product to cart
- TC-004: Remove product from cart
- TC-005: Successful checkout
