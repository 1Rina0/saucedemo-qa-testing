# Defect Log

## DEF-001
Title: Product price not aligned on Products page
Severity: Low
Status: Open
